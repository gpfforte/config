cat ~/.config/qtile/chiavi.txt | yad --text-info --geometry 1200x900 --back=#282c34 --fore=#46d9ff
