tar -cf /home/gpf/.config/dot.tar .bashrc .bash_profile .Xauthority .xinitrc .xprofile scripts/
